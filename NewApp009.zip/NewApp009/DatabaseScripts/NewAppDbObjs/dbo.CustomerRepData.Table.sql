USE [NewAppDb]
GO
/****** Object:  Table [dbo].[CustomerRepData]    Script Date: 04/16/2015 18:34:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CustomerRepData](
	[YearNo] [int] NULL,
	[MonthNo] [int] NULL,
	[RecCount] [int] NULL
) ON [PRIMARY]
GO
