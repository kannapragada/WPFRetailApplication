USE [NewAppDb]
GO
/****** Object:  Table [dbo].[SalesStatus]    Script Date: 04/16/2015 18:34:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[SalesStatus](
	[Status_id] [int] NOT NULL,
	[Status_Short] [varchar](15) NOT NULL,
	[Status_Description] [varchar](50) NOT NULL,
 CONSTRAINT [PK_SalesStatus] PRIMARY KEY CLUSTERED 
(
	[Status_id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
