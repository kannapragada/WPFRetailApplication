﻿namespace NewApp
{
    
    
    public partial class NewAppDataSet {
        partial class GetRepDataYearlyByEntityDataTable
        {
        }
    
        partial class GetStatisticsForReportDataTable
        {
        }
    
        partial class GetRepDataByDataTypeAndModeDataTable
        {
        }
    }
}

namespace NewApp.NewAppDataSetTableAdapters
{
    partial class GetStatisticsForReportTableAdapter
    {
    }
    
    
    public partial class GetRepDataByDataTypeAndModeTableAdapter {
    }
}
