﻿namespace NewApp {
    
    
    public partial class BillDataSet {
    }
}

namespace NewApp.BillDataSetTableAdapters {
    partial class BillDetailTableDataTableAdapter
    {
    }


    public partial class BillBasicTableDataTableAdapter
    {
    }
}
